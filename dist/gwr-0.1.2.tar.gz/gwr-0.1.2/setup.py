# -*- coding: utf-8 -*-
from distutils.core import setup

packages = \
['gwr']

package_data = \
{'': ['*']}

install_requires = \
['jsonpickle>=1.2,<2.0', 'numpy>=1.16,<2.0']

setup_kwargs = {
    'name': 'gwr',
    'version': '0.1.2',
    'description': 'Implementation of the Grow When Required model',
    'long_description': None,
    'author': 'yurytsoy',
    'author_email': 'yurytsoy@gmail.com',
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.5,<4.0',
}


setup(**setup_kwargs)
